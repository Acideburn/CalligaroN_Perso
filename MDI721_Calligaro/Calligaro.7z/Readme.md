1 - Dezipper l'ensemble du projet dans un dossier.
2 - Lancer et exécuter les jupyters dans l'ordre
NB : Le jupyter 1 doit créer une dossier temp (ou l'on trouvera tous les xls téléchargé)
	Le jupyter 1 créé également le fichier df_clas.pkl (objet pickle qui contient le DataFrame du classement)
	Le jupyter 2 créé le ficher df_tech.pkl (objet pickle qui contient le DataFrame des données techniques)
	L'ensemble du projet utilise ces 2 fichiers.
3 - le fichier .Doc explique ce qui a été réalisé dans les différents jupyters et les difficultés majeures